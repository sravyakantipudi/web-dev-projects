import "./NavBar.css";
import { Button, Input, Popover } from "antd";
import { DownOutlined, SearchOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";

const NavBar = () => {
  const navigate = useNavigate();
  const handleChange = () => {
    navigate("/");
  };

  return (
    <div className="nav-bar">
      <div
        className="logo"
        onClick={handleChange}
        style={{ cursor: "pointer" }}
      >
        StocksFort
      </div>

      <div className="nav-items">Alerts</div>

      <div className="nav-items">F&O</div>

      <div className="nav-items">MF</div>

      <div className="nav-items">Reports</div>

      <div className="nav-items">Screeners</div>

      <div className="nav-items">Portfolio</div>

      <div className="nav-items">More</div>
    </div>
  );
};
export default NavBar;
