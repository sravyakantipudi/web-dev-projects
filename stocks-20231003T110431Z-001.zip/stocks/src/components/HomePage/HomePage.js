import React, { useState, useEffect } from "react";
import "./HomePage.css";
import axios from "axios";
import { Input, Button, Card, List, Popover, AutoComplete } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import CoverImage from "../../assets/dvm-checklist.png";
import AutocompleteSearch from "../../AutoCompleteSearch";

const HomePage = () => {
  const [symbol, setSymbol] = useState("");
  const [dataSource, setDataSource] = useState([]);
  const [price, setPrice] = useState(null);
  const [error, setError] = useState("");
  const apiKey = "3NVGD41TMOZPTSM9";
  useEffect(() => {
    fetchStockPrice(symbol);
  }, [symbol]);

  const fetchStockPrice = async (value) => {
    try {
      const response = await axios.get(
        `https://www.alphavantage.co/query?function=SYMBOL_SEARCH&keywords=${value}&apikey=${apiKey}`
      );

      const timeSeriesData = response.data["Time Series (5min)"];
      const latestTime = Object.keys(timeSeriesData)[0];
      const latestPrice = timeSeriesData[latestTime]["4. close"];

      setPrice(latestPrice);
      setError("");
      const searchData = response.data.bestMatches || [];
      const dataSource = searchData.map((item) => ({
        value: item["1. symbol"],
        label: `${item["1. symbol"]} - ${item["2. name"]}`,
      }));
      setDataSource(dataSource);

      const news = [
        "Buy recommendation for AAPL: Strong growth potential in the tech sector.",
        "Hold recommendation for TSLA: Expecting market volatility in the coming weeks.",
        "Sell recommendation for AMZN: Recent performance indicates a downward trend.",
      ];

      const randomNewsItem = news[Math.floor(Math.random() * news.length)];
    } catch (error) {
      setPrice(null);
      setError("Error fetching stock price. Please check the symbol.");
    }
    console.log(price);
  };
  const StockDisplay = () => {
    return (
      <div
        style={{ width: "50%", height: "200px", border: "1px solid white" }}
      ></div>
    );
  };

  return (
    <div
      className="home-page"
      style={{ height: "850px", border: "1px solid black" }}
    >
      <h1
        style={{
          color: "white",
          fontSize: "45px",
          fontWeight: "400",
          fontFamily: "Kanit",
        }}
      >
        Stay ahead of the Market
      </h1>
      <h2 style={{ color: "white", fontSize: "  17px", fontWeight: "300" }}>
        Get a score for every stock with with DVM. Use screeners to maximize
        return.
        <br />
        Set real-time alerts. Get price targets and estimates.
      </h2>
      <div
        style={{
          width: "45%",
          marginTop: "30px",
          marginLeft: "auto",
          marginRight: "auto",
          display: "flex",
          flexDirection: "column",
          gap: "20px",
          alignItems: "center",
        }}
      >
        <AutocompleteSearch />
        {/* <Input
          placeholder="Search for a stock, sector, index or MF"
          prefix={<SearchOutlined color="black" />}
          size="sm"
          onChange={(e) => setSymbol(e.target.value)}
          value={symbol}
        /> */}
        <Button
          onClick={fetchStockPrice}
          type="primary"
          style={{ width: "200px" }}
        >
          Get Price
        </Button>
        {price !== null && (
          <p className="price">The current price is: ${price}</p>
        )}
      </div>
      <Card
        style={{
          width: 1000,
          height: 400,

          marginLeft: "auto",
          marginRight: "auto",
          marginTop: "80px",
          background: "rgb(2,0,36)",
          background:
            "radial-gradient(circle, rgba(2,0,36,1) 0%, rgba(4,2,62,1) 14%, rgba(5,3,77,1) 28%, rgba(4,2,55,1) 44%, rgba(9,9,121,1) 100%, rgba(0,212,255,1) 100%)",
        }}
        bordered={false}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            marginTop: "20px",
            marginLeft: "30px",
            marginBottom: "auto",
          }}
        >
          <div
            style={{
              width: "45%",
            }}
          >
            <h1 style={{ color: "white", fontSize: "35px", fontWeight: "500" }}>
              Stocks fort is more than just numbers, Get score of stocks,
              <b>Financial Health</b>
              {""}
              <br />
              <b>& Technical momentum</b>
            </h1>
          </div>
          <div style={{ width: "55%" }}>
            <img
              src={CoverImage}
              alt="cover"
              style={{ width: "400px", height: "330px" }}
            />
          </div>
        </div>
      </Card>
    </div>
  );
};
export default HomePage;
